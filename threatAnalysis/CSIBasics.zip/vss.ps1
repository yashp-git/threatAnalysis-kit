﻿$s1 = (gwmi -List Win32_ShadowCopy).Create("C:\", "ClientAccessible") 

$s2 = gwmi Win32_ShadowCopy | ? { $_.ID -eq $s1.ShadowID } 

$d  = $s2.DeviceObject + "\" 

cmd /c mklink /d C:\shadowcopy "$d"