read-host
write-host 'dir E:\data\*.* | Get-FileHash | select path, hash | Group-Object hash'
read-host
dir E:\data\*.* | Get-FileHash | select path, hash | Group-Object hash

read-host
write-host 'dir E:\data\*.* | Group-Object lastwritetime'
read-host
dir E:\data\*.* | Group-Object lastwritetime
read-host

write-host 'dir E:\data\1.txt | gm -Name *time'
read-host
dir E:\data\1.txt | gm -Name *time
read-host

write-host '$d=(Get-Item e:\data\1.txt).lastwritetime;  dir E:\data\*.* | foreach {if ($_.lastwritetime -ne $d) {$_.creationtime=$d; $_.lastwritetime=$d; $_.lastaccesstime=$d}}'
read-host
$d=(Get-Item e:\data\1.txt).lastwritetime;  dir E:\data\*.* | foreach {if ($_.lastwritetime -ne $d) {$_.creationtime=$d; $_.lastwritetime=$d; $_.lastaccesstime=$d}}
write-host 'OK.'
read-host

write-host 'e:\tzworks\jp64.exe -partition e'
read-host
e:\tzworks\jp64.exe -partition e 
read-host

write-host 'e:\tzworks\jp64.exe -partition e -show_dir_path'
read-host
e:\tzworks\jp64.exe -partition e -show_dir_path
read-host

write-host 'fsutil usn readjournal e:'
read-host
fsutil usn readjournal e: 
read-host
