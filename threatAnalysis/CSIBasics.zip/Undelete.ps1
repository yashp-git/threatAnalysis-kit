﻿$VHDPath="c:\Analysis\ForeDemo.vhdx"  

$disk= Mount-VHD -Path $VHDPath 
Import-Module PowerForensics -Verbose  

 

Get-ForensicFileRecord -VolumeName x: | Where-Object {$_.Deleted}
$fr=Get-ForensicFileRecord -VolumeName x: -Index 38 
$fr.Attribute

$fd=$fr.Attribute | Where-Object {$_.name -eq 'DATA'} 
$fd.DataRun
Get-ForensicVolumeBootRecord -VolumeName x:

Invoke-ForensicDD -InFile \\.\X: -Offset (8267*4096) -BlockSize (130*4096) -Count 1 -OutFile c:\Analysis\test.exe  

$fd

$bytes = [System.IO.File]::ReadAllBytes("c:\Analysis\test.exe") 
$bytes = $bytes[0..531367] 
[System.IO.File]::WriteAllBytes('c:\Analysis\test2.exe',$bytes)  


for ($j=0; $j -lt 10; $j++) { for ($i=0;$i -lt 10;$i++) {"cqure" | Out-File -FilePath "x:\wipeme$j.txt" -Encoding ascii -Append}} 

cipher /w:x:\

Get-ForensicFileRecord -VolumeName X: -Index 5

(Get-ForensicFileRecord -VolumeName X: -Index 0).CopyFile("c:\Analysis\xmft.txt")

for ($i=0;$i -lt 10;$i++) {"cqure" | Out-File -FilePath x:\wipeme.txt -Encoding ascii -Append}




$VHDPath="c:\Users\Paula\Desktop\Ignite\Hook\ForeDemo.vhdx" 

Dismount-VHD -Path $VHDPath 

Remove-Item $VHDPath 

Remove-Item c:\Analysis\test.exe 

Remove-Item c:\Analysis\test2.exe 

Remove-Item c:\Analysis\xmft.txt